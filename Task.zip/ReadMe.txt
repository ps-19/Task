Certain Important points:

1. 'registration.php' is root file and rest are its substitutes.
2. 'CSS' and 'JS' are Bootstrap libraries folder.
3. Database username 'root' and password ''(none).
4. My Local Database named as 'accounts' and Table named as 'users'.
5. Frontend can be improved and protected to a great extent, since it was not mentioned in task so didn't cared much about it.